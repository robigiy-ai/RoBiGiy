import dynamic from 'next/dynamic'
const RoboGiyHome = dynamic(() => import('../components/RobogiyHome'), { ssr: false })
export default function Home() {
  return <RoboGiyHome />
}