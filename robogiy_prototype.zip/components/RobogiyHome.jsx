
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Camera, ShoppingCart } from "lucide-react";

export default function RoboGiyHome() {
  const [showRoboMirror, setShowRoboMirror] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [avatarPreviewUrl, setAvatarPreviewUrl] = useState(null);

  const products = [
    { id: 1, title: "Siyah Basic Sweat", price: "₺219", img: "/mock/product1.jpg" },
    { id: 2, title: "Camel Blazer", price: "₺449", img: "/mock/product2.jpg" },
    { id: 3, title: "Oversize Hoodie", price: "₺199", img: "/mock/product3.jpg" },
    { id: 4, title: "Gri Fermuarlı Hoodie", price: "₺249", img: "/mock/product4.jpg" },
  ];

  function handleImageUpload(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setUploadedImage(url);
    setAvatarPreviewUrl(url);
  }

  function openTryOn(product) {
    setSelectedProduct(product);
    setShowRoboMirror(true);
  }

  return (
    <div className="min-h-screen bg-[#05060a] text-white font-inter">
      <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="text-2xl font-bold tracking-wide">ROB OGIY</div>
          <nav className="hidden md:flex gap-6 text-sm opacity-90">
            <a className="hover:opacity-100">Kadın</a>
            <a className="hover:opacity-100">Erkek</a>
            <a className="hover:opacity-100">Yeni Gelenler</a>
            <a className="hover:opacity-100">İndirim</a>
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <button className="hidden md:inline-flex items-center gap-2 border border-[#0ea5ff] rounded-lg px-4 py-2 text-sm">
            <Camera size={16} /> Yapay Zeka ile Dene
          </button>
          <button className="p-2 rounded-full bg-white/5">
            <ShoppingCart size={18} />
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6">
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <motion.h1
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="text-5xl md:text-6xl font-extrabold leading-tight"
            >
              KENDİNİ
              <br />
              Giydir
            </motion.h1>

            <p className="text-lg text-white/80">
              Evden kalkmadan dijital ikizine kıyafet dene. Yapay zekâ ile bedenine en uygun hale getir.
            </p>

            <div className="flex gap-4">
              <label className="inline-flex items-center gap-3 bg-[#06202a] border border-[#0ea5ff] rounded-lg px-4 py-3 cursor-pointer">
                <input onChange={handleImageUpload} type="file" accept="image/*" className="hidden" />
                <Camera size={18} />
                <span className="text-sm">Fotoğraf Yükle</span>
              </label>

              <button
                onClick={() => setShowRoboMirror(true)}
                className="inline-flex items-center gap-2 px-4 py-3 rounded-lg bg-gradient-to-r from-[#0ea5ff] to-[#4fd1c5] text-black font-semibold"
              >
                Dijital İkizimi Oluştur
              </button>
            </div>

            <div className="mt-4 text-sm text-white/60">
              <strong>Gizlilik:</strong> Fotoğrafların yalnızca avatar oluşturmak için kullanılır. (Demo uyarlaması)
            </div>
          </div>

          <div className="relative">
            <div className="w-full h-96 bg-gradient-to-br from-black/40 via-[#06111a] to-black rounded-2xl flex items-center justify-center overflow-hidden">
              <img src="/mock/hero-robot-human.png" alt="hero" className="object-cover h-full w-full mix-blend-screen" />
            </div>
          </div>
        </section>

        <section className="mt-16">
          <h2 className="text-2xl font-bold mb-6">Trend Vitrin</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {products.map((p) => (
              <motion.div
                key={p.id}
                whileHover={{ scale: 1.02 }}
                className="bg-[#071018] rounded-xl p-4 flex flex-col gap-4"
              >
                <div className="rounded-lg bg-white/5 h-56 flex items-center justify-center overflow-hidden">
                  <img src={p.img} alt={p.title} className="object-cover h-full w-full" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold">{p.title}</div>
                  <div className="text-sm text-white/60">{p.price}</div>
                </div>
                <div className="mt-2 flex gap-2">
                  <button
                    onClick={() => openTryOn(p)}
                    className="flex-1 border border-[#0ea5ff] rounded-lg py-2 text-sm"
                  >
                    ÜZERİMDE GÖR
                  </button>
                  <button className="px-4 py-2 bg-white/6 rounded-lg text-sm">Sepete Ekle</button>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        <footer className="mt-20 border-t border-white/5 pt-8 pb-12 text-sm text-white/70">
          <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
            <div>© {new Date().getFullYear()} RoboGiy</div>
            <div className="flex gap-6">
              <a>Hakkımızda</a>
              <a>İletişim</a>
              <a>Gizlilik</a>
            </div>
          </div>
        </footer>
      </main>

      {showRoboMirror && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowRoboMirror(false)} />

          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.35 }}
            className="relative max-w-4xl w-full bg-gradient-to-br from-[#071018] to-[#04101a] rounded-2xl p-6 z-10"
          >
            <div className="flex items-start gap-6">
              <div className="w-1/2">
                <h3 className="text-2xl font-bold">RoboMirror™ - Dijital İkiz</h3>
                <p className="text-sm text-white/70 mt-2">Kendi avatarını yükle veya demo avatar ile dene.</p>

                <div className="mt-4">
                  <label className="inline-flex items-center gap-3 bg-[#06202a] border border-[#0ea5ff] rounded-lg px-4 py-3 cursor-pointer">
                    <input onChange={handleImageUpload} type="file" accept="image/*" className="hidden" />
                    <Camera size={16} />
                    <span className="text-sm">Fotoğraf Yükle</span>
                  </label>
                </div>

                <div className="mt-6 flex gap-3">
                  <button
                    onClick={() => {
                      if (selectedProduct) {
                        setTimeout(() => {
                          setAvatarPreviewUrl(uploadedImage || "/mock/avatar-demo.jpg");
                        }, 600);
                      }
                    }}
                    className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#0ea5ff] to-[#4fd1c5] text-black font-semibold"
                  >
                    Kıyafeti Avatarımda Gör
                  </button>

                  <button onClick={() => setShowRoboMirror(false)} className="px-4 py-2 rounded-lg border">
                    Kapat
                  </button>
                </div>
              </div>

              <div className="w-1/2 flex flex-col items-center gap-4">
                <div className="w-full h-64 bg-white/5 rounded-lg flex items-center justify-center overflow-hidden">
                  {avatarPreviewUrl ? (
                    <img src={avatarPreviewUrl} alt="avatar preview" className="h-full object-cover w-full" />
                  ) : (
                    <div className="text-white/50">Avatar önizlemesi burada görünecek</div>
                  )}
                </div>

                {selectedProduct ? (
                  <div className="w-full text-sm text-white/70">Seçili ürün: {selectedProduct.title} — {selectedProduct.price}</div>
                ) : (
                  <div className="text-sm text-white/60">Bir ürün seç ve avatarına uygula</div>
                )}
              </div>
            </div>

            <div className="mt-4 text-xs text-white/50">
              <strong>Not:</strong> Bu prototip frontend görünümüdür. Gerçek "üzerimde gör" deneyimi için aşağıdaki entegrasyonlar gerekli:
              <ul className="list-disc ml-4 mt-2">
                <li>Backend API: /api/avatar-create (fotoğraf -> 3D/2D avatar)</li>
                <li>Backend API: /api/try-on (avatar + ürün -> önizleme görseli veya video)</li>
                <li>Model önerisi: RealisticVision / custom image-to-image + human parsing model</li>
              </ul>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
